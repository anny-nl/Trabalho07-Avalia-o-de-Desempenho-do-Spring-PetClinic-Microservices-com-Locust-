'use strict';

angular.module('ownerForm')
    .component('ownerForm', {
        templateUrl: 'scripts/owner-form/owner-form.template.html',
        controller: 'OwnerFormController'
    });
